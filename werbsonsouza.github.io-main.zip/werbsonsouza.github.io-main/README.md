##
<h1>Olá mundo, eu sou Werbson <img  src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/gifs/Hi.gif" width="30px">
</h1>

- 🕵️ Me interesso por análise de dados
- 🤓 Gosto de números
- 📊 Planilhas eletrônicas
- 📚 Livros
- 🚴‍♂️ Ciclismo
- 📫 Se quiserem pode me enviar uma mensagem
##

<div align="center">
  <a href="https://github.com/WerbsonSouza">
    </a>
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=WerbsonSouza&show_icons=true&theme=blue-green&include_all_commits=true&count_private=true"/>
</div>
  
##
Redes
<div> 
  <p><a href = "mailto:werbsonsouza.cad@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank">
    </a></p>
  <p><a href="https://www.linkedin.com/in/werbsonsouza/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank">
    </a></p>
  <p><a href="http://lattes.cnpq.br/9110996923226049" target="_blank"><img width="80px" src="http://portal.cnpq.br/image/journal/article?img_id=6616143&t=1541414552121">
    </a></p>
 </div>

##
  <img width="100px" src="https://img.shields.io/badge/manjaro-35BF5C?style=for-the-badge&logo=manjaro&logoColor=white" />
  <p> E eu uso o manjaro </p>
